﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;

using Newtonsoft.Json;
using Newtonsoft.Json.Converters;


namespace GinTub.Services.DataContracts
{

    [DataContract, JsonObject(MemberSerialization = MemberSerialization.OptIn)]
    public class MessageChoiceData
    {
        [DataMember, JsonProperty]
        public int Id { get; set; }

        [DataMember, JsonProperty]
        public string Text { get; set; }
    }

    [DataContract, JsonObject(MemberSerialization = MemberSerialization.OptIn)]
    public class MessageData
    {
        [DataMember, JsonProperty]
        public int Id { get; set; }

        [DataMember, JsonProperty]
        public string Text { get; set; }

        [DataMember, JsonProperty]
        public IEnumerable<MessageChoiceData> MessageChoices { get; set; }
    }

    [DataContract, JsonObject(MemberSerialization = MemberSerialization.OptIn)]
    public class WordData
    {
        [DataMember, JsonProperty]
        public int? NounId { get; set; }

        [DataMember, JsonProperty]
        public string Text { get; set; }
    }

    [DataContract, JsonObject(MemberSerialization = MemberSerialization.OptIn)]
    public class ParagraphStateData
    {
        [DataMember, JsonProperty]
        public int Id { get; set; }

        [DataMember, JsonProperty]
        public int Order { get; set; }

        [DataMember, JsonProperty]
        public int? RoomState { get; set; }

        [DataMember, JsonProperty]
        public IEnumerable<WordData> Words { get; set; }
    }

    [DataContract, JsonObject(MemberSerialization = MemberSerialization.OptIn)]
    public class RoomStateData
    {
        [DataMember, JsonProperty]
        public int Id { get; set; }

        [DataMember, JsonProperty]
        public int State { get; set; }

        [DataMember, JsonProperty]
        public TimeSpan Time { get; set; }

        [DataMember, JsonProperty]
        public string Location { get; set; }
    }

    [DataContract, JsonObject(MemberSerialization = MemberSerialization.OptIn)]
    public class RoomData
    {
        [DataMember, JsonProperty]
        public int Id { get; set; }

        [DataMember, JsonProperty]
        public string Name { get; set; }

        [DataMember, JsonProperty]
        public int X { get; set; }

        [DataMember, JsonProperty]
        public int Y { get; set; }

        [DataMember, JsonProperty]
        public int Z { get; set; }
    }

    [DataContract, JsonObject(MemberSerialization = MemberSerialization.OptIn)]
    public class AreaData
    {
        [DataMember, JsonProperty]
        public int Id { get; set; }

        [DataMember, JsonProperty]
        public string Name { get; set; }
    }

    [DataContract, JsonObject(MemberSerialization = MemberSerialization.OptIn)]
    public class PlayData
    {
        [DataMember, JsonProperty]
        public AreaData Area { get; set; }

        [DataMember, JsonProperty]
        public RoomData Room { get; set; }

        [DataMember, JsonProperty]
        public IEnumerable<RoomStateData> RoomStates { get; set; }

        [DataMember, JsonProperty]
        public IEnumerable<ParagraphStateData> ParagraphStates { get; set; }

        [DataMember, JsonProperty]
        public MessageData Message { get; set; }
    }
}