﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.ServiceModel.Description;
using System.Web;

using GinTub.Services;
using GinTub.Services.Hosting.EndpointBehaviors;


namespace GinTub.Services.Hosting
{

    public class GinTubServiceHostFactory : ServiceHostFactory
    {
        #region MEMBER FIELDS
        #endregion


        #region MEMBER PROPERTIES
        #endregion


        #region MEMBER METHODS

        #region Public Functionality

        public override System.ServiceModel.ServiceHostBase CreateServiceHost(string constructorString, Uri[] baseAddresses)
        {
            var host = base.CreateServiceHost(constructorString, baseAddresses);

            var endpoint = host.Description.Endpoints.FirstOrDefault(e => e.Name == "ginTubEndpoint");
            if (endpoint != null)
                endpoint.EndpointBehaviors.Add(new JsonRestBehavior());

            return host;
        }

        #endregion


        #region Protected Functionality

        protected override ServiceHost CreateServiceHost(Type serviceType, Uri[] baseAddresses)
        {
            var serviceHost = base.CreateServiceHost(serviceType, baseAddresses);
            return serviceHost;
        }

        #endregion


        #region Private Functionality
        #endregion

        #endregion
    }

}