﻿using System.ServiceModel.Channels;
using System.Xml;


namespace GinTub.Services.Hosting.Serialization
{

    public class RawBodyWriter : BodyWriter
    {
        #region MEMBER FIELDS

        private byte[] m_content;

        #endregion


        #region MEMBER PROPERTIES
        #endregion


        #region MEMBER METHODS

        #region Public Functionality

        public RawBodyWriter(byte[] content) : base(true)
        {
            m_content = content;
        }

        #endregion


        #region Protected Functionality

        protected override void OnWriteBodyContents(XmlDictionaryWriter writer)
        {
            writer.WriteStartElement("Binary");
            writer.WriteBase64(m_content, 0, m_content.Length);
            writer.WriteEndElement();
        }

        #endregion


        #region Private Functionality
        #endregion

        #endregion
    }

}